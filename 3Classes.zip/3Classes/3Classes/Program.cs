﻿public class Movie
{
    public string title;
    public string genre;
    public int year;

    public Movie (string userMovieTitle, string userMovieGenre, int userMovieYear)
    {
        this.title = userMovieTitle;
        this.genre = userMovieGenre;
        this.year = userMovieYear;
    }


}

public class Firework
{
    private string brand;
    public string Brand
    {
        get { return brand; }
        set { brand = value; }
    }

    public string category;
    public string name;

    public Firework(string userFireworkBrand, string userFireworkCategory, string userFireworkName)
    {
        Brand = userFireworkBrand;
        category = userFireworkCategory;
        name = userFireworkName;
    }
}

public class Electronic
{
    public string title;
    public string company;
    public string usage;

    public Electronic(string userElectronicTitle, string userElectronicCompany, string userElectronicUsage)
    {
        title = userElectronicTitle;
        company = userElectronicCompany;
        usage = userElectronicUsage;
    }


}

class Program
{
    static void Main(string[] args)
    {
        Movie movie1 = new Movie("Uncharted", "Action", 2022);
        Movie movie2 = new Movie("Spider-Man: No Way Home", "Superhero", 2021);
        Movie movie3 = new Movie("Joker", "Drama/Crime", 2019);

        Console.WriteLine("\"" + movie1.title + "\"" + "," + " " + movie1.genre + "," + " " + movie1.year);
        Console.WriteLine("\"" + movie2.title + "\"" + "," + " " + movie2.genre + "," + " " + movie2.year);
        Console.WriteLine("\"" + movie3.title + "\"" + "," + " " + movie3.genre + "," + " " + movie3.year);

        Console.WriteLine("\n");

        Firework firework1 = new Firework("Mad Ox", "200g Cake", "Rodeo");
        Firework firework2 = new Firework("Keystone", "500g Cake", "Detonator");
        Firework firework3 = new Firework("Keysone", "Mortar", "Double Whammy");

        Console.WriteLine(String.Format("I really like the {0} brand {1}, \"{2},\" it's really cool!", firework1.Brand, firework1.category, firework1.name));
        Console.WriteLine(String.Format("I really like the {0} brand {1}, \"{2},\" it's very colorful!", firework2.Brand, firework2.category, firework2.name));
        Console.WriteLine(String.Format("I really like the {0} brand {1}, \"{2},\" it's super loud!", firework3.Brand, firework3.category, firework3.name));

        Console.WriteLine("\n");

        Electronic electronic1 = new Electronic("Playstation 5", "Sony", "gaming");
        Electronic electronic2 = new Electronic("Switch", "Nintendo", "gaming");
        Electronic electronic3 = new Electronic("iPhone XR", "Apple", "smartphone");

        Console.WriteLine(String.Format("I own a {0} {1}, and I use it most for {2}", electronic1.company, electronic1.title, electronic1.usage));
        Console.WriteLine(String.Format("I own a {0} {1}, and I also use it for {2}", electronic2.company, electronic2.title, electronic2.usage));
        Console.WriteLine(String.Format("I own an {0} {1}, and I use it as my {2}", electronic3.company, electronic3.title, electronic3.usage));
    }
}

